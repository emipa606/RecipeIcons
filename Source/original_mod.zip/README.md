# RecipeIcons

Adds icons for the "Add bill" menu. Supports other mods out of the box.

Safe to add and remove from save games.